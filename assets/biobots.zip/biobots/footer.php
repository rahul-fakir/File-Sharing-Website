
<footer>
	<?php $themeOptions = get_option( 'chrs_theme_options' ); ?>
	<ul class="footer-social">
		<li><a href="<?php echo $themeOptions['twurl']; ?>" target="_blank"><i class="fa fa-twitter"></i></a></li>
		<li><a href="<?php echo $themeOptions['liurl']; ?>" target="_blank"><i class="fa fa-linkedin"></i></a></li>
		<li><a href="<?php echo $themeOptions['igurl']; ?>" target="_blank"><i class="fa fa-instagram"></i></a></li>
		<li><a href="<?php echo $themeOptions['fburl']; ?>" target="_blank"><i class="fa fa-facebook"></i></a></li>
	</ul>
	<p class="copy tac">&copy; <?php echo date('Y'); ?> <?php echo bloginfo('name'); ?></p>
</footer>

<script>
	var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
		showLeft = document.getElementById( 'showLeft' ),
		body = document.body;

	showLeft.onclick = function() {
		classie.toggle( this, 'active' );
		classie.toggle( menuLeft, 'cbp-spmenu-open' );
		disableOther( 'showLeft' );
	};

	function disableOther( button ) {
		if( button !== 'showLeft' ) {
			classie.toggle( showLeft, 'disabled' );
		}
	}
	
jQuery("#showLeft").toggle(
	function() {
		jQuery(".open-nav").hide();
		jQuery(".close-nav").show();
	}, 
	function() {
		jQuery(".close-nav").hide();
		jQuery(".open-nav").show();
	}
);

</script>

<?php wp_footer();?>

</body>
</html>