<?php 
show_admin_bar( false );
include_once (get_template_directory().'/functions/common.php');		
include_once (get_template_directory().'/functions/shortcodes.php');		
include_once (get_template_directory().'/functions/woo-functions-main.php');

add_theme_support('woocommerce');

// Featured Image
add_theme_support( 'post-thumbnails' );
add_image_size( 'banner', 960, 180, true );
add_image_size( 'post-thumb', 400, 400, true );
add_image_size( 'post-banner', 1200, 400, true );

function my_myme_types($mime_types){
    $mime_types['svg'] = 'image/svg+xml'; //Adding svg extension
    $mime_types['stl'] = 'application/sla';
    $mime_types['gcode'] = 'text/plain';
    $mime_types['ini'] = 'text/plain';
    return $mime_types;
}
add_filter('upload_mimes', 'my_myme_types', 1, 1);

// Register Menus
function register_chrs_menus() {
  register_nav_menus( array(
	'header-menu' => __( 'Header Menu' ),
    'footer-menu' => __( 'Footer Menu' ),
	)
  );
}
add_action( 'init', 'register_chrs_menus' );

function add_first_and_last($output) {
  $output = preg_replace('/class="menu-item/', 'class="first-menu-item menu-item', $output, 1);
  $output = substr_replace($output, 'class="last-menu-item menu-item', strripos($output, 'class="menu-item'), strlen('class="menu-item'));
  return $output;
}
add_filter('wp_nav_menu', 'add_first_and_last');

// Register Sidebar
if ( function_exists('register_sidebar') ) {
   register_sidebar(array(
   'name' => 'Blog Sidebar',
   'id' => 'blog-sidebar',
   'before_widget' => '<div class="side-widget">',
   'after_widget' => '</div>',
   'before_title' => '<h3 class="widget-title">',
   'after_title' => '</h3>'
   ));
}
  
// Register Scripts
function chrs_enqueue_scripts(){
	if (!is_admin()):
	wp_enqueue_script('chrs_jqueryui',get_template_directory_uri() . '/js/jquery-ui.js',array('jquery'),'1.11.4',true);
	wp_enqueue_script('chrs_flexslider',get_template_directory_uri() . '/js/flexslider-min.js',array('jquery'),'2.6.0',true);
	wp_enqueue_script('chrs_classie',get_template_directory_uri() . '/js/classie.js',array('jquery'),'1.0.0',true);
	wp_enqueue_script('chrs_formalizer',get_template_directory_uri() . '/js/jquery.formalize.min.js',array('jquery'),'1.0.0',true);
	wp_enqueue_script('chrs_viewport',get_template_directory_uri() . '/js/viewport.js',array('jquery'),'1.3.2',true);
	wp_enqueue_script('chrs_custom',get_template_directory_uri() . '/js/custom.js',array('jquery'),'1.0.0',true);
	endif;
}
add_action('wp_print_scripts', 'chrs_enqueue_scripts');

function chrs_customize_excerpt_more( $more ) {
    return '... <a class="read-more" href="' . get_permalink( get_the_ID() ) . '">' . __( 'Read More', 'chrs' ) . '</a>';
}
add_filter('excerpt_more', 'chrs_customize_excerpt_more');

// Gravity Forms anchor - disable auto scrolling of forms
add_filter("gform_confirmation_anchor", create_function("","return false;"));
?>