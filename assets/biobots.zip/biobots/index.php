<?php get_header();?>

<style type="text/css">
@media only screen and (max-width:768px) {
	#blog-archive-hero {height:230px;}
}

</style>


	<section id="blog-archive-hero" style="background:url(<?php echo get_template_directory_uri(); ?>/images/banner-blog.jpg) no-repeat center center;-webkit-background-size: cover;-moz-background-size: cover;-o-background-size: cover;background-size: cover;">
	</section>
	
	<section id="blog-archive" class="spacer">
		<div class="container">
			<div class="row">
				<div class="two-thirds column">
					<div class="archive-content">
						<?php if (have_posts()) : ?><?php while (have_posts()) : the_post(); ?>
						<div class="post">
							<div class="row">
								<?php if(has_post_thumbnail()) { ?>
									<div class="post-thumb">
										<div class="post-thumb-inner">
											<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_post_thumbnail('post-thumb'); ?></a>
										</div>
									</div>
								<div class="entry post-entry">
								<?php } else { ?>
								<div class="entry full-post-entry">
								<?php } ?>
									<div class="post-date">
										<span><?php the_time('F') ?> <?php the_time('d') ?>, <?php the_time('Y')?></span>
									</div>
									<h2 class="post-title"><a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h2>
									<?php the_excerpt();?>
								</div>
							</div>
						</div>
						<?php endwhile;?>
						
						<div class="row remove-bottom">
							<div class="pager left"><?php next_posts_link('&larr; Older Posts') ?></div>
							<div class="pager right"><?php previous_posts_link('Newer Posts &rarr;') ?></div>
						</div>
						
						<?php else : ?>	
						<p>Entry Not Found - <a href="<?php echo get_option('home');?>/">Back Home</a></p>
						<?php endif; ?>
					</div>
				</div>
				<div class="one-third column last">
					<?php get_sidebar(); ?>
				</div>
			</div>
		</div>
	</section>

<?php get_footer();?>
