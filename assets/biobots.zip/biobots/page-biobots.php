<?php
/*
Template Name: BioBots
*/
?>

<?php get_header();?>

<style type="text/css">
.page-banner-inner {background:url(<?php echo get_template_directory_uri(); ?>/images/banner-biobots.jpg) no-repeat center center;-webkit-background-size: cover;-moz-background-size: cover;-o-background-size: cover;background-size: cover;}

@media only screen and (max-width:1199px) {
	.page-banner-inner {background-image:url(<?php echo get_template_directory_uri(); ?>/images/banner-biobots-mid.jpg); }
}
@media only screen and (max-width:768px) {
	#home-hero {background:url(<?php echo get_template_directory_uri(); ?>/images/banner-biobots-mid.jpg) no-repeat center right;-webkit-background-size: cover;-moz-background-size: cover;-o-background-size: cover;background-size: cover;}
	.page-banner-inner {background:none;}
	.page-banner-content {padding:100px 20px 20px !important;background:rgba(255,255,255,0.8);}
}


</style>

	<section id="home-hero">
		<div class="container">
			<div class="page-banner-inner" >
				<div class="row">
					<div class="one-half column">
						<div class="page-banner-content">
							<h1 class="divider divider-top divider-lrg divider-red">What will you build?</h1>
							<p>BioBot 1 is a desktop 3D bioprinter that builds 3D living tissues out of human cells. It is a beautifully designed, precision manufactured robot that prints cells and bioinks, bringing a new dimension to biology.</p>
							<ul class="product-options biobot-buy">
							<li class="init">
							<a class="option-price" href="<?php echo home_url(); ?>/cart/?add-to-cart=119" style="color:#fff;">$10,000</a>
							<a class="option-cart-btn" href="<?php echo home_url(); ?>/cart/?add-to-cart=119">Buy</a>
							</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	
	<section id="intro-highlights" class="spacer border-t border-b">
		<div class="container">
			<h2 class="tac">Key Features</h2>
			<div class="narrow">
				<div class="row">
					<div class="highlight-block">
						<img src="<?php echo get_template_directory_uri(); ?>/images/dual-heated.png" />
						<span>01</span>
						<p>Dual Heated Extruders</p>
					</div>
					<div class="highlight-block">
						<img src="<?php echo get_template_directory_uri(); ?>/images/visible-light.png" />
						<span>02</span>
						<p>Visible Light Photocuring</p>
					</div>
					<div class="highlight-block last">
						<img src="<?php echo get_template_directory_uri(); ?>/images/100-um.png" />
						<span>03</span>
						<p>100 um Resolution</p>
					</div>					
				</div>
			</div>
		</div>
	</section>
	
	<section id="home-facts" class="spacer">
		<div class="container">
			<h2 class="tac">The Facts Behind Our Design</h2>
			<div class="fact-1">
				<div class="row mt50">
					<div class="one-half column first">
						<img src="<?php echo get_template_directory_uri(); ?>/images/fact-small-footprint.jpg" />
					</div>
					<div class="one-half column last">
						<h3>SMALL FOOTPRINT</h3>
						<p>BioBot 1 is the first desktop 3D bioprinter. With a measurement of only 12 inches cubed, BioBot 1 was designed to fit into any bio-safety hood to ensure the system is easy to use and easy to sterilize within your existing work environment.</p>
						<h3>ACCESSIBLE</h3>
						<p>We designed BioBot 1 to be the most accessible 3D bioprinter in the world. It is easy to upload designs, choose biomaterials, and print tissues. We support the use of standard lab dishes, whether that’s circular petri dishes or 96 well plates.</p>
					</div>	
				</div>
			</div>
			<div class="fact-2">
			<div class="row mt50">
				<div class="one-half column last">
					<img src="<?php echo get_template_directory_uri(); ?>/images/fact-visible-light.jpg" />
				</div>
				<div class="one-half column first">
					<h3>VISIBLE LIGHT TECHNOLOGY</h3>
					<p>BioBot 1 uses visible blue light to cure biomaterials rapidly without damaging cells.</p>
					<h3>DUAL EXTRUDER SYSTEM </h3>
					<p>BioBot 1 includes two heated extruder heads, with temperatures ranging from room temperature to 120°C.</p>
					<h3>OPEN SYSTEM</h3>
					<p>The cartridge houses two disposable BD syringes, making it easy to switch between materials and ensure sterility. Users can choose any bioink that can be extruded from a syringe.</p>
				</div>			
			</div>
			</div>
			<div class="fact-3">
			<div class="row mt50">
				<div class="one-half column first">
					<img src="<?php echo get_template_directory_uri(); ?>/images/fact-pressure-driven.jpg" />
				</div>
				<div class="one-half column last">
					<h3>PRESSURE DRIVEN</h3>
					<p>BioBot 1 runs off of a compressed air pneumatic system, making it very easy to achieve clean starts and stops in printing. Pressure ranges between 0 and 100 PSI accommodate a wide range of viscous materials.</p>
					<h3>PRECISION</h3>
					<p>Our team of engineers has worked hard to ensure precision in every aspect of BioBot 1. We use linear rails over less expensive belt systems that slip and require adjustment, guaranteeing a consistent 10 micron precision on each axis.</p>
				</div>			
			</div>
			</div>
		</div>
	</section>
	
	<section id="home-quotes" class="large-spacer bg-darkgreen">
		<div class="container">
			<h2 class="tac white">Testimonials</h2>
			<div class="testimonials" style="margin-top:50px;">
				<ul class="slides">
				<?php while ( have_rows('testimonials') ) : the_row(); ?>
				<li class="quote tac">
					<div class="narrow">
					<p>"<?php the_sub_field('content'); ?>"</p>
					<p><span class="lightgreen"><?php the_sub_field('name'); ?></span></p>
					</div>
				</li>
				<?php endwhile; ?>
				</ul>
			</div>
		</div>
	</section>
	
	<section id="tech-specs" class="spacer">
		<div class="container">
			<h2 class="tac">Tech Specs</h2>
			<div class="row mt50">
				<div class="one-third column">
					<h4 class="divider divider-top divider-sml divider-red">Size and Weight</h4>
					<p>Height: 12 inches<br />Width: 12 inches<br />Depth: 12 inches<br />Weight: 19 lbs</p>
				</div>
				<div class="one-third column">
					<h4 class="divider divider-top divider-sml divider-red">Mechanical</h4>
					<p>Construction: Aluminum Frame<br />Build Structure: Tissue Culture Plates<br />Stepper Motors: 0.9 Degrees Step Angle<br />XY Position Precision: 5.5 microns<br />Z Position: 5 microns</p>
				</div>
				<div class="one-third column last">
					<h4 class="divider divider-top divider-sml divider-red">Extruders</h4>
					<p>Extruder 1 - heated extrusion<br />Max Temp: 100 Degrees Celcius<br />Extruder 2 - Photocuring extrusion<br />LED range - 405 - 410 nm</p>
				</div>
			</div>
			<div class="row mt30">
				<div class="one-third column">
					<h4 class="divider divider-top divider-sml divider-red divider-red">Printing</h4>
					<p>Print Technology: Fused Deposition<br />Manufacturing<br />Build Volume: 9 cm x 9 cm x 9 cm (729 cm3)<br />3.5 in x 3.5 in x 3.5 in (42.87 in3)<br />Layer Resolution: 100 micron<br />Nozzle Diameter: 100 micron<br />Print File Type: GCode</p>
				</div>
				<div class="one-third column">
					<h4 class="divider divider-top divider-sml divider-red">Electrical + Operating Requirements</h4>
					<p>Power Requirements: 6 Amp AC Desktop Adaptor<br />Connectivity: USB<br />Software<br />Operating Systems: PC and Mac OS<br />Bundle: Modified Repetier Host<br />Build Structure: Tissue Culture Plates</p>
				</div>
			</div>
		</div>
	</section>
	
	<?php get_template_part( 'partials/content', 'faq' ); ?>

	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	<?php the_content(); ?>
	<?php endwhile; endif; ?>

<?php get_footer();?>
