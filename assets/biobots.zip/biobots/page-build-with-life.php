<?php
/*
Template Name: Build With Life
*/
?>

<?php get_header();?>
	<section id="home-hero" style="background:url(<?php the_field('bwl_banner'); ?>) 45px center;-webkit-background-size: cover;-moz-background-size: cover;-o-background-size: cover;background-size: cover;position:relative;">
		<div class="home-banner-wrap" style="background:none;">
			<div class="home-banner-inner">
				<h2 class="divider divider-top divider-lrg divider-red"><?php the_field('bwl_title'); ?></h2>
				<p><?php the_field('bwl_content'); ?></p>
				<?php the_widget('SearchWikisWidget'); ?>
			</div>
		</div> 
	</section>
	
	<section id="home-customers" class="spacer bg-grey">
		<div class="container">
			<h2 class="tac">Discover More</h2>
			<div class="row mt50">
				<div class="one-third column first">
					<div class="bwl-category-inner">
						<h3 class="tac"><?php the_field('bwl_category1_title') ?></h3>
						<p><?php the_field('bwl_category1_teaser'); ?></p>
<?php 
	$posts = get_posts( 
		array(
			'numberposts' => 10,
			'post_type' => 'incsub_wiki',
			'incsub_wiki_category' => 'biowiki'
		));
	foreach ( $posts as $post ) :
		setup_postdata( $post ); ?>
		<div class="row">
			<div class="bwl-entry">
				<h4 class="post-title">
					<a href="<?php the_permalink(); ?>">
						<?php the_title(); ?>
					</a>
				</h4>
			</div>
		</div>
<?php 	endforeach;
	wp_reset_postdata(); ?>
					</div>
				</div>
				<div class="one-third column">
					<div class="bwl-category-inner">
						<h3 class="tac"><?php the_field('bwl_category2_title') ?></h3>
						<p><?php the_field('bwl_category2_teaser'); ?></p>
<?php 
	$posts = get_posts( 
		array(
			'numberposts' => 10,
			'post_type' => 'incsub_wiki',
			'incsub_wiki_category' => 'protocols'
		));
	foreach ( $posts as $post ) :
		setup_postdata( $post ); ?>
		<div class="row">
			<div class="bwl-entry">
				<h4 class="post-title">
					<a href="<?php the_permalink(); ?>">
						<?php the_title(); ?>
					</a>
				</h4>
			</div>
		</div>
<?php 	endforeach;
	wp_reset_postdata(); ?>

					</div>
				</div>
				<div class="one-third column last">
					<div class="bwl-category-inner">
						<h3 class="tac"><?php the_field('bwl_category3_title') ?></h3>
						<p><?php the_field('bwl_category3_teaser'); ?></p>
<?php 
	$posts = get_posts( 
		array(
			'numberposts' => 10,
			'post_type' => 'incsub_wiki',
			'incsub_wiki_category' => 'bioreports'
		));
	foreach ( $posts as $post ) :
		setup_postdata( $post ); ?>
		<div class="row">
			<div class="bwl-entry">
				<h4 class="post-title">
					<a href="<?php the_permalink(); ?>">
						<?php the_title(); ?>
					</a>
				</h4>
			</div>
		</div>
<?php 	endforeach;
	wp_reset_postdata(); ?>
					</div>
				</div>
			</div>
		</div>
	</section>

<?php get_footer();?>