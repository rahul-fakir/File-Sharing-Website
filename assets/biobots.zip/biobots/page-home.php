<?php
/*
Template Name: Home
*/
?>

<?php get_header();?>
	<section id="home-hero" style="background:url(<?php the_field('intro_banner'); ?>) no-repeat center center;-webkit-background-size: cover;-moz-background-size: cover;-o-background-size: cover;background-size: cover;position:relative;">
		<div class="home-banner-wrap">
			<div class="home-banner-inner">
				<h1 class="divider divider-top divider-lrg divider-red"><?php the_field('intro_title'); ?></h1>
				<p><?php the_field('intro_content'); ?></p>
				<?php if ( (get_field('intro_button_lable')) || (get_field('intro_button_link')) ) { ?>
				<a href="<?php the_field('intro_button_link'); ?>" class="banner-btn"><?php the_field('intro_button_lable'); ?></a>
				<?php } ?>
			</div>
		</div>
		<div class="intro-arrow animated bounce"><i class="fa fa-chevron-down"></i></div>
	</section>
	
	<section id="home-shop" class="spacer">
		<div class="container">
			<h2 class="tac">What We Do</h2>
			<p class="tac">BioBots creates 3D bioprinters and bioinks that are unleashing the biological revolution.</p>
			
			<div class="row">
				<div class="one-third column">
					<div class="home-shop-link circle-1">
						<img src="<?php echo get_template_directory_uri(); ?>/images/shop-hardware.png" />
						<div class="plus"></div>
						<div class="shop-link-overlay tac">
							<div class="shop-link-overlay-inner">
								<h3 class="divider divider-btm divider-sml divider-ctr divider-grey">HARDWARE</h3>
								<p>Desktop 3D bioprinters</p>
								<a href="<?php echo home_url(); ?>/biobot-1/" class="btn btn-sml">Shop Now</a>
							</div>
						</div>
					</div>
				</div>
				<div class="one-third column">
					<div class="home-shop-link circle-2">
						<img src="<?php echo get_template_directory_uri(); ?>/images/shop-software.png" />
						<div class="plus"></div>
						<div class="shop-link-overlay tac">
							<div class="shop-link-overlay-inner">
								<h3 class="divider divider-btm divider-sml divider-ctr divider-grey">SOFTWARE</h3>
								<p>A platform to import and print 3D designs</p>
								<a href="#" class="btn btn-sml">Coming Soon</a>
							</div>
						</div>
					</div>
				</div>
				<div class="one-third column last">
					<div class="home-shop-link circle-3">
						<img src="<?php echo get_template_directory_uri(); ?>/images/shop-wetware.png" />
						<div class="plus"></div>
						<div class="shop-link-overlay tac">
							<div class="shop-link-overlay-inner">
								<h3 class="divider divider-btm divider-sml divider-ctr divider-grey">WETWARE</h3>
								<p>Materials for building with life</p>
								<a href="<?php echo home_url(); ?>/bioinks/" class="btn btn-sml">Shop Now</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
		
	<section id="home-customers" class="spacer bg-grey">
		<div class="container">
			<h2 class="tac">Our Customers</h2>
			<div class="row mt50">
				<div class="one-half column">
					<div class="home-customer-inner">
						<h3 class="tac">Leong Lab @<br />Columbia University</h3>
						<p>"We are very glad to be one of the labs that bought this printer and explored its function. In general, this system is very convenient to use, the interface is user friendly, and the printer works stable. I personally like it very much."</p>
						<p><strong>Dr. Zaozao Chen</strong></p>
					</div>
				</div>
				<div class="one-half column last">
					<div class="home-customer-inner">
						<h3 class="tac">Mortari Lab @<br />University of Minnesota</h3>
						<p>"Working with BioBots has allowed us to embark on new directions in research to answer important questions in tissue engineering and disease modeling. The bioprinters are cleverly designed, cost-efficient, and very user friendly. The company itself is forward-thinking, energetic, and truly committed to helping scientists make advances in 3D bioprinting."</p>
						<p><strong>Angela Panoskaltsis-Mortari, PhD</strong></p>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section id="home-community" class="spacer">
		<div class="container">
			<h2 class="tac">Our Community</h2>
			<div class="community-graph">
				<img src="<?php echo get_template_directory_uri();?>/images/community-graph-globe.png" />
				<img src="<?php echo get_template_directory_uri();?>/images/community-graph-overlay.png" class="graph-overlay" />
			</div>
			<ul class="mobile-custom-logos">
				<li><img src="<?php echo get_template_directory_uri();?>/images/customer-01.png" /></li>
				<li><img src="<?php echo get_template_directory_uri();?>/images/customer-02.png" /></li>
				<div class="clearer"></div>
				<li><img src="<?php echo get_template_directory_uri();?>/images/customer-03.png" /></li>
				<li><img src="<?php echo get_template_directory_uri();?>/images/customer-05.png" /></li>
				<div class="clearer"></div>
				<li><img src="<?php echo get_template_directory_uri();?>/images/customer-04.png" /></li>
				<li><img src="<?php echo get_template_directory_uri();?>/images/customer-06.png" /></li>
				<div class="clearer"></div>
				<li><img src="<?php echo get_template_directory_uri();?>/images/customer-07.png" /></li>
				<li><img src="<?php echo get_template_directory_uri();?>/images/customer-08.png" /></li>
				<div class="clearer"></div>
				<li><img src="<?php echo get_template_directory_uri();?>/images/customer-09.png" /></li>
				<li><img src="<?php echo get_template_directory_uri();?>/images/customer-10.png" /></li>
				<div class="clearer"></div>			
			</ul>
			<a href="<?php echo home_url(); ?>/biobot-1/" class="btn btn-sml btn-red">Join Us</a>
		</div>
	</section>

	<section id="home-quotes" class="large-spacer bg-darkgreen">
		<div class="container">
			<h2 class="tac white">What They’re Saying</h2>
			<div class="testimonials" style="margin-top:50px;">
				<ul class="slides">
				<?php while ( have_rows('press') ) : the_row(); ?>
				<li class="quote tac">
					<div class="narrow">

					<?php
					if(get_sub_field('logo')) {
					echo '<p><img src="'.get_sub_field('logo').'" /></p>';
					}
					?>
					<p>"<?php the_sub_field('content'); ?>"</p>
					</div>
				</li>
				<?php endwhile; ?>
				</ul>
			</div>
		</div>
	</section>
	
	<section id="contact" class="spacer bg-grey">
		<div class="container">
			<h2 class="tac divider divider-btm divider-lrg divider-ctr divider-red">Contact Us</h2>
			<div class="row">
				<?php echo do_shortcode('[gravityform id="3" title="false" description="false"]'); ?>
			</div>
		</div>
	</section>

	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	<?php the_content(); ?>
	<?php endwhile; endif; ?>

<?php get_footer();?>
