<?php
/*
Template Name: Shop
*/
?>

<?php get_header();?>

<style type="text/css">
.page-banner-inner {background:url(<?php echo get_template_directory_uri(); ?>/images/banner-shop.jpg) no-repeat center center;-webkit-background-size: cover;-moz-background-size: cover;-o-background-size: cover;background-size: cover;}

@media only screen and (max-width:768px) {
	.page-banner-inner {background:url(<?php echo get_template_directory_uri(); ?>/images/banner-shop-sml.jpg) no-repeat center center;-webkit-background-size: cover;-moz-background-size: cover;-o-background-size: cover;background-size: cover;}
	.page-banner-content {padding:50px 20px 20px !important;background:rgba(255,255,255,0.8);}
	.page-banner-content p {line-height:1.2;}
}

</style>

	<section id="bioinks-hero">
		<div class="container">
			<div class="page-banner-inner">
				<div class="row">
					<div class="one-half column">
						<div class="page-banner-content">
							<h2 class="divider divider-top divider-lrg divider-red">Tissue printing</h2>
							<p>To print living tissues we start with a great support material, something that can maintain structural integrity and degrade after printing. We then choose a matrix or scaffold, these gels are tissue specific and we use different ones for different cell types. The key to having a successful print is to cure your scaffold; matrix on its own won’t retain its shape, that’s why we choose the best curing agents to make sure our matrix hardens. The last step is to choose your cells and print your tissue!</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<section id="bioink-archive">
		<div class="bg-darkgreen">
			<h2 class="shop-section-title tac lightgreen">Support Bioinks</h2>
		</div>

		<?php
			$args = array(
				'post_type' => 'product',
				'showposts' => -1,
				'product_cat' => 'support-materials'
			);
			query_posts($args);
			$p=0;
			while (have_posts()) : the_post();
			$p++;
		?>

		<style type="text/css">
		ul.support-<?php echo $p; ?> li:not(.init) { display: none;}
		ul.support-<?php echo $p; ?> li:not(.init) .option-size { border-radius:0;}
		.no-round {border-radius:10px 0 0 0 !important;}
		</style>
		<div class="spacer <?php if($p==1) { ?>bg-grey<?php } ?> bioink-row support-row-<?php echo $p; ?>">
			<div class="container">
				<div class="row">
					<div class="product-desc">
						<?php if(get_post_meta(get_the_id(), 'bwl_wiki_link')): ?>
							<h3>
								<a href="<?php echo get_post_meta(get_the_id(), 'bwl_wiki_link')[0]; ?>">
									<?php the_title(); ?>
								</a>
							</h3>
						<?php else: ?>
							<h3><?php the_title(); ?></h3>
						<?php endif; ?>
						<?php the_content(); ?>

					</div>
					<div class="product-buy-wrap">
						<script type="text/javascript">
						jQuery(function($) {
							$("ul.support-<?php echo $p; ?>").on("click", ".option-size", function() {
								$(this).addClass('no-round');
								$(this).closest("ul.support-<?php echo $p; ?>").children('li:not(.init)').toggle();
								$(this).closest("ul.support-<?php echo $p; ?>").children('li:not(.init)').css({"border-radius": "0 0 0 0"});
								$(this).closest("ul.support-<?php echo $p; ?>").children('.active').toggle();
							});

							var allOptions = $("ul.support-<?php echo $p; ?>").children('li:not(.init)');
							$("ul.support-<?php echo $p; ?>").on("click", "li:not(.init)", function() {
								$(".option-size").removeClass('no-round');
								allOptions.removeClass('selected');
								$(this).addClass('selected');
								$("ul.support-<?php echo $p; ?>").children('.init').html($(this).html());
								allOptions.toggle();
								jQuery( "ul.product-options li:not(.init)" ).css({"display": "none"});
							});
						});

						/*jQuery(document).ready(function() {
							jQuery( "ul.support-<?php echo $p; ?> .option-size" ).click(function() {
							  jQuery(this).toggleClass( "no-round" );
							});
						});
						*/

						jQuery(document).mouseup(function (e)
						{
							var container = jQuery(".product-options");

							if (!container.is(e.target) // if the target of the click isn't the container...
								&& container.has(e.target).length === 0) // ... nor a descendant of the container
							{
								jQuery(".option-size").removeClass('no-round');
								jQuery( "ul.product-options li:not(.init)" ).css({"display": "none"});
							}
						});

						</script>
						<?php
						global $woocommerce, $product;
						$available_variations = $product->get_available_variations();
						$attributes = $product->get_attributes();

						//echo '<select name="product-size">';
						?>
						<ul class="product-options support-<?php echo $p; ?>" id="product-options-<?php echo $p; ?>">
						<?php

						sort($available_variations);
						$i=0;
						foreach ($available_variations as $prod_variation) :
							$i++;
							?>
							<?php
							if($i==1) {
								$listItem = 'init';
							} else {
								$listItem = '';
							}
								foreach ($prod_variation['attributes'] as $attr_name => $attr_value) :
									// Get the correct variation values
									if (strpos($attr_name, '_pa_')){ // variation is a pre-definted attribute
									$attr_name = substr($attr_name, 10);
									$attr = get_term_by('slug', $attr_value, $attr_name);
									$attr_value = $attr->name;
								}
								$variation_slug = $attr_value;
								endforeach;

							echo '<li data-value="value '.$i.'" class="value-'.$i.' '.$listItem.'">';
							echo '<span class="option-size">'.$variation_slug.'</span>';
							echo '<span class="option-price">$'.$prod_variation['display_regular_price'].'</span>';
							echo '<a class="option-cart-btn" href="'.home_url().'/cart/?add-to-cart='.$post->ID.'&variation_id='.$prod_variation['variation_id'].'&attribute_pa_size='.$variation_slug.'">add to cart</a>';
							echo '</li>';

							if ($i == 1) {
								echo '<li data-value="value '.$i.'" class="value-'.$i.'">';
								echo '<span class="option-size">'.$variation_slug.'</span>';
								echo '<span class="option-price">$'.$prod_variation['display_regular_price'].'</span>';
								echo '<a class="option-cart-btn" href="'.home_url().'/cart/?add-to-cart='.$post->ID.'&variation_id='.$prod_variation['variation_id'].'&attribute_pa_size='.$variation_slug.'">add to cart</a>';
								echo '</li>';
							}

								//echo '<a href="'.home_url().'/cart/?add-to-cart='.$post->ID.'&variation_id='.$prod_variation['variation_id'].'&attribute_pa_size='.$variation_slug.'">add to cart</a><br />';

								//echo '<pre>';
								//print_r($prod_variation);
								//echo '</pre>';
						endforeach;
						//echo '</select>';
						?>
						</ul>
					</div>
				</div>
			</div>
		</div>

		<?php endwhile; wp_reset_query(); ?>

		<div class="bg-darkgreen">
			<h2 class="shop-section-title tac lightgreen">Sacrificial Bioinks</h2>
		</div>

		<?php
			$args = array(
				'post_type' => 'product',
				'showposts' => -1,
				'product_cat' => 'sacrificial-materials'
			);
			query_posts($args);
			$p=0;
			while (have_posts()) : the_post();
			$p++;
		?>

		<style type="text/css">
		ul.sacrificial-<?php echo $p; ?> li:not(.init) { display: none;}
		ul.sacrificial-<?php echo $p; ?> li:not(.init) .option-size { border-radius:0;}
		.no-round {border-radius:10px 0 0 0 !important;}
		</style>
		<div class="spacer <?php if($p==1) { ?>bg-grey<?php } ?> bioink-row sacrificial-row-<?php echo $p; ?>">
			<div class="container">
				<div class="row">
					<div class="product-desc">
						<?php if(get_post_meta(get_the_id(), 'bwl_wiki_link')): ?>
							<h3>
								<a href="<?php echo get_post_meta(get_the_id(), 'bwl_wiki_link')[0]; ?>">
									<?php the_title(); ?>
								</a>
							</h3>
						<?php else: ?>
							<h3><?php the_title(); ?></h3>
						<?php endif; ?>
						<?php the_content(); ?>

					</div>
					<div class="product-buy-wrap">
						<script type="text/javascript">
						jQuery(function($) {
							$("ul.sacrificial-<?php echo $p; ?>").on("click", ".option-size", function() {
								$(this).addClass('no-round');
								$(this).closest("ul.sacrificial-<?php echo $p; ?>").children('li:not(.init)').toggle();
								$(this).closest("ul.sacrificial-<?php echo $p; ?>").children('li:not(.init)').css({"border-radius": "0 0 0 0"});
								$(this).closest("ul.sacrificial-<?php echo $p; ?>").children('.active').toggle();
							});

							var allOptions = $("ul.sacrificial-<?php echo $p; ?>").children('li:not(.init)');
							$("ul.sacrificial-<?php echo $p; ?>").on("click", "li:not(.init)", function() {
								$(".option-size").removeClass('no-round');
								allOptions.removeClass('selected');
								$(this).addClass('selected');
								$("ul.sacrificial-<?php echo $p; ?>").children('.init').html($(this).html());
								allOptions.toggle();
								jQuery( "ul.product-options li:not(.init)" ).css({"display": "none"});
							});
						});

						/*jQuery(document).ready(function() {
							jQuery( "ul.sacrificial-<?php echo $p; ?> .option-size" ).click(function() {
							  jQuery(this).toggleClass( "no-round" );
							});
						});
						*/

						jQuery(document).mouseup(function (e)
						{
							var container = jQuery(".product-options");

							if (!container.is(e.target) // if the target of the click isn't the container...
								&& container.has(e.target).length === 0) // ... nor a descendant of the container
							{
								jQuery(".option-size").removeClass('no-round');
								jQuery( "ul.product-options li:not(.init)" ).css({"display": "none"});
							}
						});

						</script>
						<?php
						global $woocommerce, $product;
						$available_variations = $product->get_available_variations();
						$attributes = $product->get_attributes();

						//echo '<select name="product-size">';
						?>
						<ul class="product-options support-<?php echo $p; ?>" id="product-options-<?php echo $p; ?>">
						<?php

						sort($available_variations);
						$i=0;
						foreach ($available_variations as $prod_variation) :
							$i++;
							?>
							<?php
							if($i==1) {
								$listItem = 'init';
							} else {
								$listItem = '';
							}
								foreach ($prod_variation['attributes'] as $attr_name => $attr_value) :
									// Get the correct variation values
									if (strpos($attr_name, '_pa_')){ // variation is a pre-definted attribute
									$attr_name = substr($attr_name, 10);
									$attr = get_term_by('slug', $attr_value, $attr_name);
									$attr_value = $attr->name;
								}
								$variation_slug = $attr_value;
								endforeach;

							echo '<li data-value="value '.$i.'" class="value-'.$i.' '.$listItem.'">';
							echo '<span class="option-size">'.$variation_slug.'</span>';
							echo '<span class="option-price">$'.$prod_variation['display_regular_price'].'</span>';
							echo '<a class="option-cart-btn" href="'.home_url().'/cart/?add-to-cart='.$post->ID.'&variation_id='.$prod_variation['variation_id'].'&attribute_pa_size='.$variation_slug.'">add to cart</a>';
							echo '</li>';

							if ($i == 1) {
								echo '<li data-value="value '.$i.'" class="value-'.$i.'">';
								echo '<span class="option-size">'.$variation_slug.'</span>';
								echo '<span class="option-price">$'.$prod_variation['display_regular_price'].'</span>';
								echo '<a class="option-cart-btn" href="'.home_url().'/cart/?add-to-cart='.$post->ID.'&variation_id='.$prod_variation['variation_id'].'&attribute_pa_size='.$variation_slug.'">add to cart</a>';
								echo '</li>';
							}

								//echo '<a href="'.home_url().'/cart/?add-to-cart='.$post->ID.'&variation_id='.$prod_variation['variation_id'].'&attribute_pa_size='.$variation_slug.'">add to cart</a><br />';

								//echo '<pre>';
								//print_r($prod_variation);
								//echo '</pre>';
						endforeach;
						//echo '</select>';
						?>
						</ul>
					</div>
				</div>
			</div>
		</div>

		<?php endwhile; wp_reset_query(); ?>

		<div class="bg-darkgreen">
			<h2 class="shop-section-title tac lightgreen">Matrix Bioinks</h2>
		</div>
		<?php
			$args = array(
				'post_type' => 'product',
				'showposts' => -1,
				'product_cat' => 'matrix-materials'
			);
			query_posts($args);
			$p=0;
			while (have_posts()) : the_post();
			$p++;
		?>

		<style type="text/css">
		ul.matrix-<?php echo $p; ?> li:not(.init) { display: none;}
		ul.matrix-<?php echo $p; ?> li:not(.init) .option-size { border-radius:0;}
		</style>
		<div class="spacer bioink-row matrix-row-<?php echo $p; ?>">
			<div class="container">
				<div class="row">
					<div class="product-desc">
						<?php if(get_post_meta(get_the_id(), 'bwl_wiki_link')): ?>
							<h3>
								<a href="<?php echo get_post_meta(get_the_id(), 'bwl_wiki_link')[1]; ?>">
									<?php the_title(); ?>
								</a>
							</h3>
						<?php else: ?>
							<h3><?php the_title(); ?></h3>
						<?php endif; ?>
						<?php the_content(); ?>
					</div>
					<div class="product-buy-wrap">
						<script type="text/javascript">
						jQuery(function($) {
							$("ul.matrix-<?php echo $p; ?>").on("click", ".option-size", function() {
								$(this).addClass('no-round');
								$(this).closest("ul.matrix-<?php echo $p; ?>").children('li:not(.init)').toggle();
								$(this).closest("ul.matrix-<?php echo $p; ?>").children('.active').toggle();
							});

							var allOptions = $("ul.matrix-<?php echo $p; ?>").children('li:not(.init)');
							$("ul.matrix-<?php echo $p; ?>").on("click", "li:not(.init)", function() {
								allOptions.removeClass('selected');
								$(".option-size").removeClass('no-round');
								$(this).addClass('selected');
								$("ul.matrix-<?php echo $p; ?>").children('.init').html($(this).html());
								allOptions.toggle();
								jQuery( "ul.product-options li:not(.init)" ).css({"display": "none"});
							});
						});

						</script>

						<?php
						global $woocommerce, $product;
						$available_variations = $product->get_available_variations();
						$attributes = $product->get_attributes();

						//echo '<select name="product-size">';
						?>
						<ul class="product-options matrix-<?php echo $p; ?>">
						<?php

						sort($available_variations);
						$i=0;
						foreach ($available_variations as $prod_variation) :
						$i++;
						?>
						<?php
						if($i==1) {
							$listItem = 'init';
						} else {
							$listItem = '';
						}
							foreach ($prod_variation['attributes'] as $attr_name => $attr_value) :
								// Get the correct variation values
								if (strpos($attr_name, '_pa_')){ // variation is a pre-definted attribute
								$attr_name = substr($attr_name, 10);
								$attr = get_term_by('slug', $attr_value, $attr_name);
								$attr_value = $attr->name;
							}
							$variation_slug = $attr_value;
							endforeach;

						echo '<li data-value="value '.$i.'" class="value-'.$i.' '.$listItem.'">';
						echo '<span class="option-size">'.$variation_slug.'</span>';
						echo '<span class="option-price">$'.$prod_variation['display_regular_price'].'</span>';
						echo '<a class="option-cart-btn" href="'.home_url().'/cart/?add-to-cart='.$post->ID.'&variation_id='.$prod_variation['variation_id'].'&attribute_pa_size='.$variation_slug.'">add to cart</a>';
						echo '</li>';

						if ($i == 1) {
							echo '<li data-value="value '.$i.'" class="value-'.$i.'">';
							echo '<span class="option-size">'.$variation_slug.'</span>';
							echo '<span class="option-price">$'.$prod_variation['display_regular_price'].'</span>';
							echo '<a class="option-cart-btn" href="'.home_url().'/cart/?add-to-cart='.$post->ID.'&variation_id='.$prod_variation['variation_id'].'&attribute_pa_size='.$variation_slug.'">add to cart</a>';
							echo '</li>';
						}
							//echo '<a href="'.home_url().'/cart/?add-to-cart='.$post->ID.'&variation_id='.$prod_variation['variation_id'].'&attribute_pa_size='.$variation_slug.'">add to cart</a><br />';

							//echo '<pre>';
							//print_r($prod_variation);
							//echo '</pre>';
						endforeach;
						//echo '</select>';
						?>
						</ul>
					</div>
				</div>
			</div>
		</div>

		<?php endwhile; wp_reset_query(); ?>

		<div class="bg-darkgreen">
			<h2 class="shop-section-title tac lightgreen">Curing Bioinks</h2>
		</div>
		<?php
			$args = array(
				'post_type' => 'product',
				'showposts' => -1,
				'product_cat' => 'curing-materials'
			);
			query_posts($args);
			$p=0;
			while (have_posts()) : the_post();
			$p++;
		?>

		<style type="text/css">
		ul.curing-<?php echo $p; ?> li:not(.init) { display: none;}
		ul.curing-<?php echo $p; ?> li:not(.init) .option-size { border-radius:0;}
		</style>
		<div class="spacer bioink-row curing-row-<?php echo $p; ?>">
			<div class="container">
				<div class="row">
					<div class="product-desc">
						<?php if(get_post_meta(get_the_id(), 'bwl_wiki_link')): ?>
							<h3>
								<a href="<?php echo get_post_meta(get_the_id(), 'bwl_wiki_link')[1]; ?>">
									<?php the_title(); ?>
								</a>
							</h3>
						<?php else: ?>
							<h3><?php the_title(); ?></h3>
						<?php endif; ?>

						<?php the_content(); ?>
					</div>
						<div class="product-buy-wrap">
							<script type="text/javascript">
						jQuery(function($) {
							$("ul.curing-<?php echo $p; ?>").on("click", ".option-size", function() {
								$(this).closest("ul.curing-<?php echo $p; ?>").children('li:not(.init)').toggle();
								$(this).closest("ul.curing-<?php echo $p; ?>").children('.active').toggle();
								$(this).addClass('no-round');
							});

							var allOptions = $("ul.curing-<?php echo $p; ?>").children('li:not(.init)');
							$("ul.curing-<?php echo $p; ?>").on("click", "li:not(.init)", function() {
								allOptions.removeClass('selected');
								$(this).addClass('selected');
								$("ul.curing-<?php echo $p; ?>").children('.init').html($(this).html());
								allOptions.toggle();
								$(".option-size").removeClass('no-round');
								jQuery( "ul.product-options li:not(.init)" ).css({"display": "none"});
							});
						});

						</script>

						<?php
						global $woocommerce, $product;
						$available_variations = $product->get_available_variations();
						$attributes = $product->get_attributes();

						//echo '<select name="product-size">';
						?>
						<ul class="product-options curing-<?php echo $p; ?>">
						<?php

						sort($available_variations);
						$i=0;
						foreach ($available_variations as $prod_variation) :
						$i++;
						?>
						<?php
						if($i==1) {
							$listItem = 'init';
						} else {
							$listItem = '';
						}
							foreach ($prod_variation['attributes'] as $attr_name => $attr_value) :
								// Get the correct variation values
								if (strpos($attr_name, '_pa_')){ // variation is a pre-definted attribute
								$attr_name = substr($attr_name, 10);
								$attr = get_term_by('slug', $attr_value, $attr_name);
								$attr_value = $attr->name;
							}
							$variation_slug = $attr_value;
							endforeach;

						echo '<li data-value="value '.$i.'" class="value-'.$i.' '.$listItem.'">';
						echo '<span class="option-size">'.$variation_slug.'</span>';
						echo '<span class="option-price">$'.$prod_variation['display_regular_price'].'</span>';
						echo '<a class="option-cart-btn" href="'.home_url().'/cart/?add-to-cart='.$post->ID.'&variation_id='.$prod_variation['variation_id'].'&attribute_pa_size='.$variation_slug.'">add to cart</a>';
						echo '</li>';

						if ($i == 1) {
							echo '<li data-value="value '.$i.'" class="value-'.$i.'">';
							echo '<span class="option-size">'.$variation_slug.'</span>';
							echo '<span class="option-price">$'.$prod_variation['display_regular_price'].'</span>';
							echo '<a class="option-cart-btn" href="'.home_url().'/cart/?add-to-cart='.$post->ID.'&variation_id='.$prod_variation['variation_id'].'&attribute_pa_size='.$variation_slug.'">add to cart</a>';
							echo '</li>';
						}

							//echo '<a href="'.home_url().'/cart/?add-to-cart='.$post->ID.'&variation_id='.$prod_variation['variation_id'].'&attribute_pa_size='.$variation_slug.'">add to cart</a><br />';

							//echo '<pre>';
							//print_r($prod_variation);
							//echo '</pre>';
						endforeach;
						//echo '</select>';
						?>
						</ul>
					</div>
				</div>
			</div>
		</div>

		<?php endwhile; wp_reset_query(); ?>
	</section>
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	<?php the_content(); ?>
	<?php endwhile; endif; ?>

<?php get_footer();?>