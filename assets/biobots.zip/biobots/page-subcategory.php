<?php
/*
Template Name: Build With Life
*/
?>

<?php get_header();?>
	<section id="home-hero" style="background:url(<?php the_field('bwl_banner'); ?>) no-repeat center center;-webkit-background-size: cover;-moz-background-size: cover;-o-background-size: cover;background-size: cover;position:relative;">
		<div class="home-banner-wrap" style="background: none; width: 45%">
			<div class="home-banner-inner">
				<h2 class="divider divider-top divider-lrg divider-red"><?php the_field('bwl_title'); ?></h2>
				<p><?php the_field('bwl_content'); ?></p>
				<?php the_widget('SearchWikisWidget'); ?>
			</div>
		</div> 
	</section>
	
	<section id="home-customers" class="spacer bg-grey">
		<div class="container">
			<h2 class="tac">Discover More</h2>
			<div class="row mt50">
				<div class="one-third column first">
					<div class="bwl-category-inner">
						<h3 class="tac"><?php the_field('bwl_category1_title') ?></h3>
						<p><?php the_field('bwl_category1_teaser'); ?></p>
						<a href="<?php the_field('bwl_category1_link'); ?>" class="btn btn-small btn-red"><?php the_field('bwl_category1_label'); ?></a>
					</div>
				</div>
				<div class="one-third column">
					<div class="bwl-category-inner">
						<h3 class="tac"><?php the_field('bwl_category2_title') ?></h3>
						<p><?php the_field('bwl_category2_teaser'); ?></p>
						<a href="<?php the_field('bwl_category2_link'); ?>" class="btn btn-small btn-red"><?php the_field('bwl_category2_label'); ?></a>
					</div>
				</div>
				<div class="one-third column last">
					<div class="bwl-category-inner">
						<h3 class="tac"><?php the_field('bwl_category3_title') ?></h3>
						<p><?php the_field('bwl_category3_teaser'); ?></p>
						<a href="<?php the_field('bwl_category3_link'); ?>" class="btn btn-small btn-red"><?php the_field('bwl_category3_label'); ?></a>
					</div>
				</div>
			</div>
		</div>
	</section>

	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	<?php the_content(); ?>
	<?php endwhile; endif; ?>

<?php get_footer();?>
