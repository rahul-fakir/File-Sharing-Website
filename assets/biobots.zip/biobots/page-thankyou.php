<?php
/*
Template Name: Thank You
*/
?>

<?php get_header();?>

	<div style="position:relative;">
		<?php
			if (has_post_thumbnail( $post->ID ) ):
			$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
		?>
		<section id="cms-hero" style="background:url(<?php echo $image[0]; ?>) no-repeat center center;-webkit-background-size: cover;-moz-background-size: cover;-o-background-size: cover;background-size: cover;">
		</section>
		<?php endif; ?>
		
		<section id="cms-content" class="spacer">
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
				<h2 class="tac">
					<?php
					if(get_field('custom_title')) {
						the_field('custom_title');
					} else {
						the_title();
					}
					?>
				</h2>
				<div class="entry" style="width:100%;height:100%;">
					<div class="row">
						<?php the_content(); ?>
					</div>
				</div>			
				<?php endwhile; endif; ?>
		</section>
	</div>
	

<?php get_footer();?>
