<?php get_header();?>

<style type="text/css">
.forum-archive .page-title {display:none;}
@media only screen and (max-width:768px) {
	#cms-hero {height:230px;}
}
</style>

	<?php
		if (has_post_thumbnail( $post->ID ) ):
		$image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'full' );
	?>
	<section id="cms-hero" style="background:url(<?php echo $image[0]; ?>) no-repeat center center;-webkit-background-size: cover;-moz-background-size: cover;-o-background-size: cover;background-size: cover;">
	</section>
	<?php endif; ?>
	
	<section id="cms-content" class="spacer">
		<div class="container">
			<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
			<h1 class="page-title tac">
				<?php
				if(get_field('custom_title')) {
					the_field('custom_title');
				} else {
					the_title();
				}
				?>
			</h1>
			<div class="entry">
				<div class="row">
					<?php the_content(); ?>
				</div>
			</div>			
			<?php endwhile; endif; ?>
		</div>	
	</section>
	
	<?php
		// Contact Thank You page
		if(is_page(47)) {
			get_template_part( 'partials/content', 'faq' );
		}
	?>

<?php get_footer();?>
