	<section id="faq-wrap" class="spacer">
		<div class="container">
			<h2 class="tac">Frequently Asked Questions</h2>
			
			<div id="faq" class="mt50">
				<h3 class="first">How much does BioBot 1 cost?</h3>
				<div class="bg-darkgreen">
					<p>$10,000.00</p>
				</div>
								
				<h3>Do you ship internationally?</h3>
				<div class="bg-darkgreen">
					<p>Yes, we ship internationally. Please contact us for shipping rates and specifications.</p>
				</div>
				
				<h3>Which cell lines can the BioBot 1 print?</h3>
				<div class="bg-darkgreen">
					<p>Dozens of different cell types have been tested, if you have questions about a specific cell line please email <a href="mailto:info@biobots.io?subject=Which cell lines can the BioBot 1 print?">info@biobots.io</a></p>
				</div>
				
				<h3>What materials are supported?</h3>
				<div class="bg-darkgreen">
					<p>Our partners and clients have used a wide variety of materials including collagen, gelatin, PEG, alginate, etc. Anything that can be extruded out of a syringe works.</p>
				</div>
				
				<h3>How can I contact a BioBots team member?</h3>
				<div class="bg-darkgreen">
					<p><a href="mailto:info@biobots.io?subject=Contact BioBots Team Member">info@biobots.io</a></p>
				</div>
			</div>
			
		</div>
	</section>
