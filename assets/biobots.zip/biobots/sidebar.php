<div class="sidebar">

	<?php
	// if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('blog-sidebar') ) :
	// endif;
	?>

	<div class="side-widget">
		<h3 class="widget-title cap">Archives</h3>
		<div id="archive">
			<h3 class="archive-year">Categories</h3>
			<div>
				<ul>
				<?php wp_list_categories('title_li='); ?> 
				</ul>
			</div>
	
			<?php
			/**/
			$years = $wpdb->get_col("SELECT DISTINCT YEAR(post_date)
			FROM $wpdb->posts WHERE post_status = 'publish'
			AND post_type = 'post' ORDER BY post_date DESC");
			foreach($years as $year) :
			?>
			<h3 class="archive-year"><?php echo $year; ?></h3>
			
			<div>
				<ul>
				<?php
                $months = $wpdb->get_col("SELECT DISTINCT MONTH(post_date)
				FROM $wpdb->posts WHERE post_status = 'publish' AND post_type = 'post'
				AND YEAR(post_date) = '".$year."' ORDER BY post_date DESC");
				foreach($months as $month) :
				?>
					<li>
                    <a href="<?php echo get_month_link($year, $month); ?>">
					<?php echo date( 'F', mktime(0, 0, 0, $month) );?></a></li>
		
				<?php endforeach; ?>
				</ul>
			</div>
			
			<?php endforeach; ?>
					
		</div>
		
		<script>
		jQuery(function() {
			jQuery( "#archive" ).accordion({
			heightStyle: "content",
			active: false,
			collapsible: true
			});
		});
		</script>
	</div>


</div><!--sidebar-->
