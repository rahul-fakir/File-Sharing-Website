
<?php get_header();?>
	
	<section id="blog-single" class="spacer">
		<div class="container">
			<?php if (have_posts()) : ?><?php while (have_posts()) : the_post(); ?>
			<?php $postID = $post->ID; ?>
			<div class="post">
				<div class="entry post-entry">
					<?php
						if (get_field('second_featured_image')) {
							echo '<p class="tac">';
							echo '<img src="'.get_field('second_featured_image').'" />';
							echo '</p>';
						}
					?>
					<div class="post-date">
						<span><?php the_time('F') ?> <?php the_time('d') ?>, <?php the_time('Y')?></span>
					</div>
					<h2 class="post-title"><?php the_title(); ?></h2>
					<?php the_content();?>
				</div>
				<div class="post-share-wrap">
					<div class="share">
						<!-- Go to www.addthis.com/dashboard to customize your tools -->
						<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-564d57022b82da7f" async></script>
						<!-- Go to www.addthis.com/dashboard to customize your tools -->
						<div class="addthis_sharing_toolbox"></div>
					</div>
					<div class="row">
						<div class="post-pager left"><?php previous_post_link('%link', 'Previous'); ?></div>
						<div class="post-pager right"><?php next_post_link('%link', 'Next'); ?></div>
					</div>

				</div>				
			</div>
			<?php endwhile; endif; ?>
			
			<a class="more-news" href="<?php echo home_url(); ?>/news">More Articles</a>
					
		</div>
	</section>

<?php get_footer();?>
