
<?php get_header();?>
	
	<section id="blog-single" style="<?php if (get_field('second_featured_image')) { ?>background: url(<?php the_field('second_featured_image'); ?>) no-repeat left center;-webkit-background-size: cover;-moz-background-size: cover;-o-background-size: cover;background-size: cover;<?php } else { ?>background:#008081;<?php } ?>">
		<div class="row" style="height:100%;">
			<div class="single-post-thumb">
				<h2 class="post-title divider divider-top divider-lrg divider-red"><?php the_title(); ?></h2>
			</div>
			<div class="single-post-column">
				<div class="single-post-inner">
					<?php if (have_posts()) : ?><?php while (have_posts()) : the_post(); ?>
					<?php $postID = $post->ID; ?>
						<div class="entry">
							<div class="post-date">
								<span><?php the_time('F') ?> <?php the_time('d') ?>, <?php the_time('Y')?></span>
							</div>
							<div class="row">
							<?php the_content();?>
							</div>
							<div class="post-share-wrap">
								<div class="share">
									<!-- Go to www.addthis.com/dashboard to customize your tools -->
									<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-564d57022b82da7f" async></script>
									<!-- Go to www.addthis.com/dashboard to customize your tools -->
									<div class="addthis_native_toolbox"></div>
								</div>
								<div class="row">
									<div class="post-pager left"><?php previous_post_link('%link', 'Previous'); ?></div>
									<div class="post-pager right"><?php next_post_link('%link', 'Next'); ?></div>
								</div>

							</div>
						</div>
					<?php endwhile; endif; ?>
				</div>
			</div>
		</div>
	</section>
		<?php /* ?>
			<div class="post" style="height:100%;">
				<div class="row" style="height:100%;">
					
					<div class="one-half column post-thumb-sidebar" style="height:100%;max-height:100%;overflow:scroll;">
					<?php
					if(get_field('second_featured_image')) {
						echo '<img src="'.get_field('second_featured_image').'" />';
					}
					?>
					</div>
					<div class="one-half column last" style="height:100%;max-height:100%;overflow:scroll;<?php if (!get_field('second_featured_image')) { ?>background:#fff;<?php } ?>">
						<div class="single-post">
							<?php if (have_posts()) : ?><?php while (have_posts()) : the_post(); ?>
							<?php $postID = $post->ID; ?>
								<div class="row">
									<div class="entry post-entry" style="padding:60px 0 100px;">
										<h2 class="post-title"><?php the_title(); ?></h2>
										<div class="post-date">
											<span><?php the_time('F') ?> <?php the_time('d') ?>, <?php the_time('Y')?></span>
										</div>
										<?php the_content();?>
									</div>
								</div>
							<?php endwhile; endif; ?>
						</div>
					</div>
				</div>
			</div>
			<?php */ ?>
			<?php /* ?>
			<div class="related-posts">
				<div class="view-related-posts tac">
					<span>View Other Posts</span>
				</div>
				<div class="row">
					<?php
						$args = array(
							'post_type' => 'post',
							'showposts' => 3,
							'orderby' => 'rand',
							'post__not_in' => array($postID)
						);
						query_posts($args);
						$i==0;
						while (have_posts()) : the_post();
						$i++;
					?>
					<div class="one-third column <?php if($i==3) { echo 'last'; } ; ?>">
						<div class="related-post-item">
							<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('post-thumb'); ?></a>
							<a href="<?php the_permalink(); ?>" class="related-overlay">
								<span class="related-overlay-inner">
									<span class="cap"><?php the_title(); ?></span><br >-<br /><?php the_time('F') ?> <?php the_time('d') ?>, <?php the_time('Y')?>
								</span>
							</a>
						</div>
					</div>
					<?php endwhile; wp_reset_query(); ?>
				</div>
			</div>
			<?php */ ?>
			

<?php get_footer();?>
